grant create view to C##HR1;
grant resource, connect to C##HR1;
